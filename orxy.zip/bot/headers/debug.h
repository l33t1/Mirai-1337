#pragma once

#include "includes.h"


void antiMemoryAnalysis();
void call_to_giganigga();
void timingBasedAntiDebugging();