package utils

import (
	"fmt"
	"regexp"
	"strconv"
	"strings"
	"time"
)

func ReplaceFromMap(target string, objects map[string]string) string {
	for targetValue, value := range objects {
		target = strings.ReplaceAll(target, targetValue, value)
	}
	return target
}

func ParseDuration(input string) (time.Duration, error) {
	var totalDuration time.Duration

	unitMultiplier := map[string]time.Duration{
		"d":   time.Hour * 24,
		"w":   time.Hour * 24 * 7,
		"m":   time.Hour * 24 * 30,
		"s":   time.Second,
		"min": time.Minute,
	}

	regex := regexp.MustCompile(`(\d+)([dwms]+)`)
	matches := regex.FindAllStringSubmatch(input, -1)

	for _, match := range matches {
		value, err := strconv.Atoi(match[1])
		if err != nil {
			return 0, err
		}

		units := match[2]

		multiplier, exists := unitMultiplier[units]
		if !exists {
			return 0, fmt.Errorf("unknown time unit in %s", match[0])
		}

		totalDuration += time.Duration(value) * multiplier
	}

	return totalDuration, nil
}
