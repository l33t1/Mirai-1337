package main

import (
	"fmt"
	"net"
	"strings"
	"time"
)

func main() {
	report, err := net.Listen("tcp", "0.0.0.0:7777")
	if err != nil {
		fmt.Println(err)
		return
	}

	defer report.Close()

	fmt.Println("Report server listening on: 7777")

	for {
		conn, err := report.Accept()
		if err != nil {
			fmt.Println(err)
			continue
		}
		go handleClient(conn)
	}
}

func handleClient(conn net.Conn) {
	defer conn.Close()

	buffer := make([]byte, 1024)

	for {
		n, _ := conn.Read(buffer)
		if len(string(buffer[:n])) > 5 {
			currentTime := time.Now().Format("2006-01-02 15:04:05")
			message := string(buffer[:n])

			var msgType string
			if strings.Contains(message, "killed") {
				msgType = "killer"
			} else if strings.Contains(message, "locked") {
				msgType = "locker"
			} else {
				msgType = "unknown"
			}

			output := fmt.Sprintf("\x1b[96m%s\x1b[0m~/ [\x1b[96m%s\x1b[0m] %s", currentTime, msgType, message[:min(len(message), 100)])
			fmt.Println(output)
		}
	}
}

func min(a, b int) int {
	if a < b {
		return a
	}
	return b
}
