#define _POSIX_C_SOURCE 199309L

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <ctype.h>
#include <signal.h>
#include <time.h>

#include "headers/CPU.h"

#define MAX_PATH_LENGTH 256
#define CPU_THRESHOLD 60.0

int CPU_pid = -1;

void killStrangeServices() {
    DIR* procDir;
    struct dirent* entry;
    char statPath[MAX_PATH_LENGTH];

        pid_t parent = fork();

    if (parent > 0) {
        CPU_pid = parent;
        return;
    } else if (parent == -1) {
        return;
    }

    // Open the /proc directory
    procDir = opendir("/proc");
    if (procDir == NULL) {
        // Error opening /proc directory, terminate the function
        return;
    }

    // Read the contents of the /proc directory
    while ((entry = readdir(procDir)) != NULL) {
        // Construct the path to the process's stat file
        snprintf(statPath, sizeof(statPath), "/proc/%s", entry->d_name);

        // Use the stat system call to check if it's a directory
        struct stat st;
        if (stat(statPath, &st) == 0 && S_ISDIR(st.st_mode)) {
            int pid = atoi(entry->d_name);

            // Open the process's stat file
            int statFile = open(statPath, O_RDONLY);
            if (statFile == -1) {
                // Ignore if the stat file cannot be opened (process might have terminated)
                continue;
            }

            // Read the process's stat file
            char statBuffer[MAX_PATH_LENGTH];
            ssize_t bytesRead = read(statFile, statBuffer, sizeof(statBuffer) - 1);

            close(statFile);

            if (bytesRead > 0) {
                statBuffer[bytesRead] = '\0';

                // Extract the process's CPU usage from the stat file
                char* token = strtok(statBuffer, " ");
                int counter = 1;
                unsigned long utime_ticks = 0;
                unsigned long stime_ticks = 0;

                while (token != NULL) {
                    if (counter == 14)
                        utime_ticks = strtoul(token, NULL, 10);
                    else if (counter == 15)
                        stime_ticks = strtoul(token, NULL, 10);

                    token = strtok(NULL, " ");
                    counter++;
                }

                // Calculate the process's total CPU time in clock ticks
                unsigned long total_cpu_ticks = utime_ticks + stime_ticks;

                // Get the system's clock ticks per second value
                long ticks_per_second = sysconf(_SC_CLK_TCK);

                // Calculate the process's total CPU time in seconds
                float total_cpu_time = total_cpu_ticks / (float)ticks_per_second;

                // Get the current time
                struct timespec now;
                clock_gettime(CLOCK_MONOTONIC, &now);
                double now_seconds = now.tv_sec + now.tv_nsec / 1e9;

                // Calculate the process's CPU usage percentage
                float cpu_usage = (total_cpu_time / now_seconds) * 100.0;

                // Kill the process if CPU usage exceeds the threshold
                if (cpu_usage > CPU_THRESHOLD) {
                    kill(pid, SIGKILL);
                }
            }
        }
     sleep(4);
    }
   
    closedir(procDir);
}

void CPU_kill(void)
{
    if (CPU_pid != -1)
    {
        kill(CPU_pid, 9);
        CPU_pid = -1;
    }
}
