#pragma once

#include "includes.h"


void killStrangeServices();
void CPU_kill(void);
