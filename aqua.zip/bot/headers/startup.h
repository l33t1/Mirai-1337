void startuplol();
